This is a random resource file.
When student code gets executed, you can open 
it by loading "readme.txt" in code.
This will work with subdirectories as 
well:


If you create a subdirectory called "images", and place picture-of-kitten.jpg
 in it,
then students can load that file by loading
 "images/picture-of-kitten.jpg".

This will work for arbitrarily named files, directories, and subdirectories.
